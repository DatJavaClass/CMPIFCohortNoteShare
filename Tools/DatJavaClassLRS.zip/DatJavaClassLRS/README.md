# LR Simulator

Client-side linear regression simulator for datjavaclass.com, aimed at
students who have not met regression yet. Mounts into `#djc-tool-stage` of the
"DJC - Full-Width Tool" WordPress page template.

Left pane takes data in (CSV upload with prune-to-two-columns picking, or
manual X/Y entry with spreadsheet paste), right pane shows the plots
(Scatter + Fit, Residuals, Q-Q, Histogram). Everything runs in the visitor's
browser; nothing is uploaded.

Live and ready to use at https://www.datjavaclass.com/lrs/. This bundle is the
same tool as a download, for anyone who wants to run or read the source.

## Layout

- `lr-simulator.js` - the whole app: math engine (top, pure functions,
  exported as `DJCLR`) + UI. Single file, no dependencies.
- `lr-simulator.css` - styles riding the theme's CSS variables, with
  fallbacks for standalone use.
- `dev/index.html` - harness that mirrors the live theme variables (dark
  default, `[data-dark="false"]` light). Auto-drive query params for headless
  screenshots: `?autoload=1&plot=qq&light=1`, `?manual=1`, `?readme=1`,
  `keep=col1,col2`.
- `sample-data/noteshare_snapshot_2026-07-17.csv` - a small bespoke dataset
  (the Note Share EDA-ing itself) to load and explore; the dev harness'
  "load sample" button reads it.

## Why the math can be trusted

- Two-pass centered OLS with Neumaier compensated sums and hi/lo split means;
  slope/intercept/R2/RMSE/SEs match NIST StRD certified values (Norris) to
  ~1e-14 relative and exact-arithmetic references on stress data (x offsets of
  1e8, spreads of 1e-3) to better than 1e-9 on the worst conditioned field.
- Missing values are skipped and counted, never coerced to zero.
- Inverse normal (Q-Q) is Acklam's approximation, checked against Python's
  `statistics.NormalDist.inv_cdf` to 2e-8.
- The browser UI end-to-end (parse, prune, fit, format) reproduces the same
  numbers as an independent exact-arithmetic fit of the same CSV.

Those properties were checked during development against NIST StRD certified
values and exact-arithmetic references (a 219-check suite); the engine in this
bundle is that verified build.

## Dev loop

```
python -m http.server 8613     # from the project root
# open http://localhost:8613/dev/index.html
```
