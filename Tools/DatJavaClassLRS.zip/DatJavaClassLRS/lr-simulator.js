/*!
 * DJC Linear Regression Simulator
 * Client-side only: data never leaves the visitor's browser.
 * Math engine verified against NIST StRD certified values (Norris) and
 * exact rational-arithmetic references; see tests/verify.mjs.
 */
(function () {
'use strict';

/* ================================================================
 * Math engine. Pure functions, no DOM access, exported for tests.
 * ================================================================ */

/* Neumaier compensated summation over f(0..n-1). */
function nsumBy(n, f) {
	let s = 0, c = 0;
	for (let i = 0; i < n; i++) {
		const v = f(i);
		const t = s + v;
		if (Math.abs(s) >= Math.abs(v)) c += (s - t) + v;
		else c += (v - t) + s;
		s = t;
	}
	return s + c;
}

function nsum(values) {
	return nsumBy(values.length, i => values[i]);
}

/*
 * Ordinary least squares, simple linear regression.
 * Two-pass centered computation: means first, then centered sums,
 * so large offsets (years, sensor baselines) do not cancel digits.
 * Residuals are evaluated in centered form for the same reason.
 */
/* Missing values (null, undefined, '') are NaN, never 0. */
function toNum(v) {
	if (v == null) return NaN;
	if (typeof v === 'string' && v.trim() === '') return NaN;
	return Number(v);
}

function fit(xsIn, ysIn) {
	const xs = [], ys = [];
	let skipped = 0;
	const m = Math.min(xsIn.length, ysIn.length);
	for (let i = 0; i < m; i++) {
		const x = toNum(xsIn[i]), y = toNum(ysIn[i]);
		if (Number.isFinite(x) && Number.isFinite(y)) { xs.push(x); ys.push(y); }
		else skipped++;
	}
	const n = xs.length;
	if (n < 3) return { ok: false, error: 'TOO_FEW_POINTS', n, skipped };

	/* Means kept as hi/lo double pairs: the true mean is generally not
	   representable in one double, and that half-ulp, multiplied by the
	   slope, would otherwise shift every residual. Centering as
	   (x - hi) - lo keeps each difference accurate to its own ulp. */
	const mxHi = nsumBy(n, i => xs[i]) / n;
	const mxLo = nsumBy(n, i => xs[i] - mxHi) / n;
	const myHi = nsumBy(n, i => ys[i]) / n;
	const myLo = nsumBy(n, i => ys[i] - myHi) / n;
	const meanX = mxHi + mxLo, meanY = myHi + myLo;

	const dx = new Array(n), dy = new Array(n);
	for (let i = 0; i < n; i++) {
		dx[i] = (xs[i] - mxHi) - mxLo;
		dy[i] = (ys[i] - myHi) - myLo;
	}

	const sxx = nsumBy(n, i => dx[i] * dx[i]);
	if (sxx === 0) return { ok: false, error: 'CONSTANT_X', n, skipped };
	const syy = nsumBy(n, i => dy[i] * dy[i]);
	const sxy = nsumBy(n, i => dx[i] * dy[i]);

	const slope = sxy / sxx;
	const intercept = meanY - slope * meanX;

	const fitted = new Array(n), residuals = new Array(n);
	for (let i = 0; i < n; i++) {
		const r = dy[i] - slope * dx[i];
		residuals[i] = r;
		fitted[i] = ys[i] - r;
	}
	const sse = nsumBy(n, i => residuals[i] * residuals[i]);

	/* r2 = r * r: for simple OLS this is the same quantity as 1 - SSE/Syy
	   but stays fully conditioned when R2 is near zero. */
	let r = NaN, r2 = NaN;
	if (syy > 0) {
		r = (sxy / Math.sqrt(sxx)) / Math.sqrt(syy);
		r = Math.max(-1, Math.min(1, r));
		r2 = r * r;
	}
	const sigma2 = sse / (n - 2);
	const rmse = Math.sqrt(sigma2);
	const seSlope = Math.sqrt(sigma2 / sxx);
	const seIntercept = Math.sqrt(sigma2 * (1 / n + (meanX * meanX) / sxx));

	return {
		ok: true, n, skipped, meanX, meanY, slope, intercept,
		r, r2, rmse, seSlope, seIntercept, xs, ys, fitted, residuals,
	};
}

/*
 * Inverse standard normal CDF, Acklam's rational approximation.
 * Relative error below 1.2e-9 across (0, 1); ample for Q-Q plotting.
 */
const QN_A = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
	1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00];
const QN_B = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
	6.680131188771972e+01, -1.328068155288572e+01];
const QN_C = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
	-2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00];
const QN_D = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
	3.754408661907416e+00];

function qnorm(p) {
	if (!(p > 0 && p < 1)) return NaN;
	const pl = 0.02425, ph = 1 - pl;
	let q, x;
	if (p < pl) {
		q = Math.sqrt(-2 * Math.log(p));
		x = (((((QN_C[0] * q + QN_C[1]) * q + QN_C[2]) * q + QN_C[3]) * q + QN_C[4]) * q + QN_C[5]) /
			((((QN_D[0] * q + QN_D[1]) * q + QN_D[2]) * q + QN_D[3]) * q + 1);
	} else if (p <= ph) {
		q = p - 0.5;
		const s = q * q;
		x = (((((QN_A[0] * s + QN_A[1]) * s + QN_A[2]) * s + QN_A[3]) * s + QN_A[4]) * s + QN_A[5]) * q /
			(((((QN_B[0] * s + QN_B[1]) * s + QN_B[2]) * s + QN_B[3]) * s + QN_B[4]) * s + 1);
	} else {
		q = Math.sqrt(-2 * Math.log(1 - p));
		x = -(((((QN_C[0] * q + QN_C[1]) * q + QN_C[2]) * q + QN_C[3]) * q + QN_C[4]) * q + QN_C[5]) /
			((((QN_D[0] * q + QN_D[1]) * q + QN_D[2]) * q + QN_D[3]) * q + 1);
	}
	return x;
}

/* R's ppoints(): plotting positions for a Q-Q plot. */
function ppoints(n) {
	if (n <= 0) return [];
	const a = n <= 10 ? 0.375 : 0.5;
	const out = new Array(n);
	for (let i = 0; i < n; i++) out[i] = (i + 1 - a) / (n + 1 - 2 * a);
	return out;
}

/* Quantile of a SORTED array, R type 7 (the R default). */
function quantileSorted(sorted, p) {
	const n = sorted.length;
	if (n === 0) return NaN;
	if (n === 1) return sorted[0];
	const h = (n - 1) * p;
	const lo = Math.floor(h);
	const hi = Math.min(lo + 1, n - 1);
	return sorted[lo] + (h - lo) * (sorted[hi] - sorted[lo]);
}

/* Heckbert's nice number: 1, 2, or 5 times a power of ten. */
function niceNum(range, round) {
	if (!(range > 0) || !Number.isFinite(range)) return 1;
	const exp = Math.floor(Math.log10(range));
	const f = range / Math.pow(10, exp);
	let nf;
	if (round) nf = f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10;
	else nf = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
	return nf * Math.pow(10, exp);
}

/* Axis ticks: nice step, ticks spanning [min, max]. */
function niceTicks(min, max, target) {
	target = target || 6;
	if (!Number.isFinite(min) || !Number.isFinite(max)) return { ticks: [0, 1], step: 1 };
	if (min === max) {
		const pad = min === 0 ? 1 : Math.abs(min) * 0.5;
		min -= pad; max += pad;
	}
	if (min > max) { const t = min; min = max; max = t; }
	const step = niceNum(niceNum(max - min, false) / (target - 1), true);
	const lo = Math.floor(min / step) * step;
	const hi = Math.ceil(max / step) * step;
	const ticks = [];
	/* Walk by integer multiples of step so ticks land on clean values. */
	const kLo = Math.round(lo / step), kHi = Math.round(hi / step);
	for (let k = kLo; k <= kHi; k++) {
		const v = k * step;
		ticks.push(Math.abs(v) < step * 1e-10 ? 0 : v);
	}
	return { ticks, step, lo: ticks[0], hi: ticks[ticks.length - 1] };
}

/* Histogram with Sturges bin count and nice bin edges. */
function histogram(values) {
	const v = values.filter(Number.isFinite);
	const n = v.length;
	if (n === 0) return { bins: [], width: 1, start: 0 };
	let min = Infinity, max = -Infinity;
	for (const x of v) { if (x < min) min = x; if (x > max) max = x; }
	if (min === max) {
		const w = min === 0 ? 1 : Math.abs(min) * 0.1;
		return { bins: [{ x0: min - w / 2, x1: min + w / 2, count: n }], width: w, start: min - w / 2 };
	}
	const k = Math.max(1, Math.ceil(Math.log2(n)) + 1);
	const width = niceNum((max - min) / k, true);
	const start = Math.floor(min / width) * width;
	const nb = Math.max(1, Math.ceil((max - start) / width - 1e-9));
	const bins = [];
	for (let i = 0; i < nb; i++) {
		bins.push({ x0: start + i * width, x1: start + (i + 1) * width, count: 0 });
	}
	for (const x of v) {
		let idx = Math.floor((x - start) / width);
		if (idx >= nb) idx = nb - 1; /* max lands on the closing edge */
		if (idx < 0) idx = 0;
		bins[idx].count++;
	}
	return { bins, width, start };
}

/* ================================================================
 * CSV parsing. Pure, exported for tests.
 * ================================================================ */

function detectDelimiter(line) {
	const cands = [',', ';', '\t'];
	let best = ',', bestCount = -1;
	for (const d of cands) {
		let count = 0, inQ = false;
		for (let i = 0; i < line.length; i++) {
			const ch = line[i];
			if (ch === '"') inQ = !inQ;
			else if (ch === d && !inQ) count++;
		}
		if (count > bestCount) { bestCount = count; best = d; }
	}
	return best;
}

function parseCSV(text) {
	if (typeof text !== 'string') return { rows: [], delimiter: ',' };
	if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
	const firstNL = text.search(/\r\n|\r|\n/);
	const firstLine = firstNL === -1 ? text : text.slice(0, firstNL);
	const delim = detectDelimiter(firstLine);

	const rows = [];
	let row = [], field = '', inQ = false, sawAny = false;
	const pushField = () => { row.push(field); field = ''; };
	const pushRow = () => {
		pushField();
		if (row.length > 1 || row[0].trim() !== '') rows.push(row);
		row = [];
	};
	for (let i = 0; i < text.length; i++) {
		const ch = text[i];
		if (inQ) {
			if (ch === '"') {
				if (text[i + 1] === '"') { field += '"'; i++; }
				else inQ = false;
			} else field += ch;
		} else if (ch === '"') {
			inQ = true; sawAny = true;
		} else if (ch === delim) {
			pushField(); sawAny = true;
		} else if (ch === '\n') {
			pushRow();
		} else if (ch === '\r') {
			if (text[i + 1] === '\n') i++;
			pushRow();
		} else {
			field += ch; sawAny = true;
		}
	}
	if (field !== '' || row.length > 0) pushRow();
	return { rows, delimiter: delim, sawAny };
}

/* '' or whitespace is missing (null); otherwise strict float or NaN. */
function parseCell(cell) {
	const t = String(cell == null ? '' : cell).trim();
	if (t === '') return null;
	const v = Number(t);
	return Number.isFinite(v) ? v : NaN;
}

/*
 * Build a column model from raw rows.
 * headerMode: 'auto' | true | false.
 * A column is numeric when it has at least one number and no cell that
 * fails to parse (missing cells are allowed).
 */
function analyzeTable(rows, headerMode) {
	if (!rows || rows.length === 0) return { columns: [], hasHeader: false, nRows: 0 };
	const width = rows.reduce((w, r) => Math.max(w, r.length), 0);

	const colNumericBody = (c, startRow) => {
		let any = false;
		for (let r = startRow; r < rows.length; r++) {
			const v = parseCell(rows[r][c]);
			if (v === null) continue;
			if (Number.isNaN(v)) return false;
			any = true;
		}
		return any;
	};

	let hasHeader;
	if (headerMode === true || headerMode === false) hasHeader = headerMode;
	else {
		hasHeader = false;
		if (rows.length > 1) {
			for (let c = 0; c < width; c++) {
				const h = parseCell(rows[0][c]);
				if (h !== null && Number.isNaN(h) && colNumericBody(c, 1)) { hasHeader = true; break; }
			}
			if (!hasHeader) {
				/* All-text first row over a table with any numeric body column. */
				let allText = true, anyNumericCol = false;
				for (let c = 0; c < width; c++) {
					const h = parseCell(rows[0][c]);
					if (h === null || !Number.isNaN(h)) { allText = false; break; }
				}
				for (let c = 0; c < width && allText; c++) {
					if (colNumericBody(c, 1)) { anyNumericCol = true; break; }
				}
				if (allText && anyNumericCol) hasHeader = true;
			}
		}
	}

	const startRow = hasHeader ? 1 : 0;
	const columns = [];
	for (let c = 0; c < width; c++) {
		const name = hasHeader && String(rows[0][c] || '').trim() !== ''
			? String(rows[0][c]).trim()
			: 'Column ' + (c + 1);
		const cells = [], values = [];
		let numericCount = 0, badCount = 0, missing = 0;
		for (let r = startRow; r < rows.length; r++) {
			const raw = rows[r][c] == null ? '' : String(rows[r][c]);
			cells.push(raw);
			const v = parseCell(raw);
			if (v === null) { missing++; values.push(null); }
			else if (Number.isNaN(v)) { badCount++; values.push(null); }
			else { numericCount++; values.push(v); }
		}
		columns.push({
			name, cells, values, missing,
			numeric: numericCount > 0 && badCount === 0,
			pruned: false,
		});
	}
	return { columns, hasHeader, nRows: rows.length - startRow };
}

const LR = {
	fit, qnorm, ppoints, quantileSorted, niceNum, niceTicks, histogram,
	parseCSV, parseCell, analyzeTable, nsum, nsumBy, detectDelimiter,
};

if (typeof globalThis !== 'undefined') globalThis.DJCLR = LR;

/* ================================================================
 * UI. Attaches only in a browser with the mount point present.
 * ================================================================ */

if (typeof document !== 'undefined') {
	const boot = () => {
		const stage = document.getElementById('djc-tool-stage');
		if (stage && !stage.dataset.djclrMounted) {
			stage.dataset.djclrMounted = '1';
			initSimulator(stage);
		}
	};
	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
	else boot();
}

/* ---------------------------------------------------------------- helpers */

function h(tag, attrs, ...kids) {
	const el = document.createElement(tag);
	if (attrs) for (const [k, v] of Object.entries(attrs)) {
		if (k === 'class') el.className = v;
		else if (k === 'text') el.textContent = v;
		else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
		else if (v !== false && v != null) el.setAttribute(k, v === true ? '' : v);
	}
	for (const kid of kids) if (kid != null) el.appendChild(kid);
	return el;
}

const SVGNS = 'http://www.w3.org/2000/svg';

function s(tag, attrs, ...kids) {
	const el = document.createElementNS(SVGNS, tag);
	if (attrs) for (const [k, v] of Object.entries(attrs)) {
		if (k === 'class') el.setAttribute('class', v);
		else if (k === 'text') el.textContent = v;
		else el.setAttribute(k, v);
	}
	for (const kid of kids) if (kid != null) el.appendChild(kid);
	return el;
}

function fmt(v, digits) {
	if (!Number.isFinite(v)) return 'n/a';
	digits = digits || 6;
	const a = Math.abs(v);
	if (a !== 0 && (a >= 1e7 || a < 1e-4)) return v.toExponential(Math.min(4, digits - 1));
	let str = v.toPrecision(digits);
	if (str.indexOf('.') !== -1 && str.indexOf('e') === -1) {
		str = str.replace(/0+$/, '').replace(/\.$/, '');
	}
	return str;
}

function tickLabel(v, step) {
	if (Math.abs(v) >= 1e6) return v.toExponential(1);
	const dec = Math.max(0, -Math.floor(Math.log10(step)));
	return v.toFixed(Math.min(dec, 8));
}

/* ---------------------------------------------------------------- app */

function initSimulator(stage) {
	stage.textContent = '';
	stage.style.display = 'block';
	stage.style.placeItems = 'unset';

	const state = {
		mode: 'upload',
		upload: { table: null, fileName: '', headerMode: 'auto', swapped: false, totalRows: 0 },
		manual: { rows: [] },
		fit: null,
		fitMeta: null,
		stale: false,
		activePlot: 'scatter',
	};
	for (let i = 0; i < 6; i++) state.manual.rows.push({ x: '', y: '' });

	/* -------------------- static skeleton -------------------- */

	const fileInput = h('input', { type: 'file', accept: '.csv,.tsv,.txt', style: 'display:none' });
	fileInput.addEventListener('change', () => {
		if (fileInput.files && fileInput.files[0]) loadFile(fileInput.files[0]);
		fileInput.value = '';
	});

	const msg = h('div', { class: 'djclr-msg', role: 'status' });
	const dataZone = h('div', { class: 'djclr-datazone' });
	const results = h('div', { class: 'djclr-results', hidden: true });
	const btnUpload = h('button', { type: 'button', text: 'Upload Data' });
	const btnManual = h('button', { type: 'button', text: 'Manual Entry' });
	const btnSim = h('button', { type: 'button', class: 'djclr-primary', text: 'Simulate' });
	const btnClear = h('button', { type: 'button', text: 'Clear Data' });
	const actions = h('div', { class: 'djclr-actions' }, btnUpload, btnManual, btnClear, btnSim);

	const legend = h('div', { class: 'djclr-legend' });
	const svgBox = h('div', { class: 'djclr-svgbox' });
	const staleChip = h('div', { class: 'djclr-stalechip', text: 'Data changed. Press Simulate to refresh.', hidden: true });
	const plotWrap = h('div', { class: 'djclr-plotwrap' }, staleChip, legend, svgBox);
	const pills = h('div', { class: 'djclr-pills', role: 'group', 'aria-label': 'Plot type' });

	const PLOTS = [
		['scatter', 'Scatter + Fit'],
		['resid', 'Residuals'],
		['qq', 'Q-Q'],
		['hist', 'Histogram'],
	];
	const pillBtns = {};
	for (const [key, label] of PLOTS) {
		const b = h('button', {
			type: 'button', text: label, disabled: true,
			onclick: () => { state.activePlot = key; renderPlot(); },
		});
		pillBtns[key] = b;
		pills.appendChild(b);
	}

	const btnReadme = h('button', { type: 'button', text: 'Read Me' });

	const root = h('div', { class: 'djclr' },
		h('div', { class: 'djclr-topbar' },
			h('h2', { class: 'djclr-title', text: 'Linear Regression Simulator' }),
			btnReadme),
		h('div', { class: 'djclr-panes' },
			h('div', { class: 'djclr-left' },
				dataZone, msg, results, actions,
				h('div', { class: 'djclr-privacy', text: 'Runs entirely in your browser. Your data is never uploaded anywhere.' })),
			h('div', { class: 'djclr-right' }, plotWrap, pills)),
		fileInput);
	stage.appendChild(root);

	const tip = h('div', { class: 'djclr-tip', hidden: true });
	document.body.appendChild(tip);

	const modal = buildReadme();
	document.body.appendChild(modal.el);
	btnReadme.addEventListener('click', () => modal.open(btnReadme));

	/* -------------------- tooltip -------------------- */

	function tipShow(anchor, rows) {
		tip.textContent = '';
		for (const [k, v] of rows) {
			tip.appendChild(h('div', null,
				h('span', { class: 'djclr-tip-k', text: k + ' ' }),
				h('span', { text: v })));
		}
		tip.hidden = false;
		const r = anchor.getBoundingClientRect();
		const tr = tip.getBoundingClientRect();
		let left = r.left + r.width / 2 - tr.width / 2;
		let top = r.top - tr.height - 8;
		left = Math.max(6, Math.min(left, window.innerWidth - tr.width - 6));
		if (top < 6) top = r.bottom + 8;
		tip.style.left = left + 'px';
		tip.style.top = top + 'px';
	}
	function tipHide() { tip.hidden = true; }

	/* -------------------- mode + gating -------------------- */

	function setMode(mode) {
		state.mode = mode;
		btnUpload.setAttribute('aria-pressed', mode === 'upload');
		btnManual.setAttribute('aria-pressed', mode === 'manual');
		renderDataZone();
		updateGate();
	}

	btnUpload.addEventListener('click', () => {
		if (state.mode !== 'upload') setMode('upload');
		fileInput.click();
	});
	btnManual.addEventListener('click', () => setMode('manual'));

	/* Two-step clear. */
	let clearArmed = null;
	btnClear.addEventListener('click', () => {
		if (clearArmed) {
			clearTimeout(clearArmed);
			clearArmed = null;
			btnClear.textContent = 'Clear Data';
			btnClear.classList.remove('djclr-danger-armed');
			doClear();
		} else {
			btnClear.textContent = 'Really clear?';
			btnClear.classList.add('djclr-danger-armed');
			clearArmed = setTimeout(() => {
				clearArmed = null;
				btnClear.textContent = 'Clear Data';
				btnClear.classList.remove('djclr-danger-armed');
			}, 3000);
		}
	});

	function doClear() {
		if (state.mode === 'upload') {
			state.upload.table = null;
			state.upload.fileName = '';
			state.upload.headerMode = 'auto';
			state.upload.swapped = false;
		} else {
			state.manual.rows = [];
			for (let i = 0; i < 6; i++) state.manual.rows.push({ x: '', y: '' });
		}
		state.fit = null;
		state.fitMeta = null;
		state.stale = false;
		results.hidden = true;
		renderDataZone();
		renderPlot();
		updateGate();
	}

	function markDirty() {
		if (state.fit) {
			state.stale = true;
			staleChip.hidden = false;
			plotWrap.classList.add('djclr-stale');
			results.style.opacity = '0.45';
		}
		updateGate();
	}

	function survivors() {
		const t = state.upload.table;
		if (!t) return [];
		return t.columns.map((c, i) => ({ c, i })).filter(e => !e.c.pruned);
	}

	function roleCols() {
		const sv = survivors();
		if (sv.length !== 2) return null;
		const [a, b] = sv;
		return state.upload.swapped ? { x: b, y: a } : { x: a, y: b };
	}

	function gate() {
		if (state.mode === 'upload') {
			const t = state.upload.table;
			if (!t) return { ok: false, text: 'Upload a CSV file to begin, or switch to Manual Entry.' };
			const sv = survivors();
			if (sv.length > 2) return { ok: false, text: 'Prune down to 2 columns to simulate. ' + sv.length + ' remaining: click the ✕ on columns you do not need.' };
			if (sv.length < 2) return { ok: false, text: 'Only ' + sv.length + ' column' + (sv.length === 1 ? '' : 's') + ' left. Restore ' + (2 - sv.length) + ' from the pruned tray below.' };
			const roles = roleCols();
			const bad = [roles.x, roles.y].filter(e => !e.c.numeric);
			if (bad.length) return { ok: false, text: 'Column "' + bad[0].c.name + '" is not numeric, so it cannot be plotted. Prune it and keep numeric columns.' };
			return { ok: true, text: 'Ready: X = ' + roles.x.c.name + ', Y = ' + roles.y.c.name + '. Press Simulate.' };
		}
		let complete = 0;
		for (const row of state.manual.rows) {
			const x = LR.parseCell(row.x), y = LR.parseCell(row.y);
			if (x !== null && y !== null && !Number.isNaN(x) && !Number.isNaN(y)) complete++;
		}
		if (complete < 3) return { ok: false, text: 'Enter at least 3 rows with both X and Y (' + complete + ' so far). Tip: you can paste two columns straight from a spreadsheet.' };
		return { ok: true, text: 'Ready: ' + complete + ' points. Press Simulate.' };
	}

	function updateGate() {
		const g = gate();
		btnSim.disabled = !g.ok;
		msg.textContent = g.text;
		msg.classList.remove('djclr-msg-err');
	}

	/* -------------------- upload pane -------------------- */

	function loadFile(file) {
		if (file.size > 8 * 1024 * 1024) {
			msg.textContent = 'That file is over 8 MB. Trim it down and try again.';
			msg.classList.add('djclr-msg-err');
			return;
		}
		file.text().then(text => {
			const parsed = LR.parseCSV(text);
			if (!parsed.rows.length) {
				msg.textContent = 'Could not find any rows in that file.';
				msg.classList.add('djclr-msg-err');
				return;
			}
			state.upload.totalRows = parsed.rows.length;
			state.upload.rawRows = parsed.rows.slice(0, 20000);
			state.upload.fileName = file.name;
			state.upload.headerMode = 'auto';
			state.upload.swapped = false;
			state.upload.table = LR.analyzeTable(state.upload.rawRows, 'auto');
			markDirty();
			renderDataZone();
			updateGate();
		});
	}

	function rebuildTable() {
		const prunedNames = new Set(
			(state.upload.table ? state.upload.table.columns : [])
				.filter(c => c.pruned).map(c => c.name));
		state.upload.table = LR.analyzeTable(state.upload.rawRows, state.upload.headerMode);
		for (const c of state.upload.table.columns) {
			if (prunedNames.has(c.name)) c.pruned = true;
		}
	}

	function renderDataZone() {
		dataZone.textContent = '';
		if (state.mode === 'upload') renderUpload();
		else renderManual();
	}

	function renderUpload() {
		const t = state.upload.table;
		if (!t) {
			const drop = h('div', {
				class: 'djclr-drop', tabindex: '0', role: 'button',
				'aria-label': 'Upload a CSV file',
				onclick: () => fileInput.click(),
				onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); } },
			},
				h('div', null, h('strong', { text: 'Drop a CSV file here' })),
				h('div', { text: 'or click to browse. First row can be column names.' }));
			drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('djclr-drop-over'); });
			drop.addEventListener('dragleave', () => drop.classList.remove('djclr-drop-over'));
			drop.addEventListener('drop', e => {
				e.preventDefault();
				drop.classList.remove('djclr-drop-over');
				if (e.dataTransfer.files && e.dataTransfer.files[0]) loadFile(e.dataTransfer.files[0]);
			});
			dataZone.appendChild(drop);
			return;
		}

		/* file bar */
		const headerToggle = h('input', { type: 'checkbox' });
		headerToggle.checked = t.hasHeader;
		headerToggle.addEventListener('change', () => {
			state.upload.headerMode = headerToggle.checked;
			rebuildTable();
			markDirty();
			renderDataZone();
			updateGate();
		});
		const truncNote = state.upload.totalRows > 20000
			? ' (first 20000 of ' + state.upload.totalRows + ' rows kept)' : '';
		dataZone.appendChild(h('div', { class: 'djclr-filebar' },
			h('span', { class: 'djclr-filename', text: state.upload.fileName + truncNote }),
			h('label', null, headerToggle, h('span', { text: 'First row is column names' }))));

		/* preview table */
		const roles = roleCols();
		const table = h('table', null);
		const trh = h('tr', null);
		t.columns.forEach((col, idx) => {
			if (col.pruned) return;
			const inner = h('div', { class: 'djclr-th-inner' });
			if (roles && roles.x.i === idx) inner.appendChild(h('span', { class: 'djclr-role-chip djclr-role-x', text: 'X' }));
			if (roles && roles.y.i === idx) inner.appendChild(h('span', { class: 'djclr-role-chip djclr-role-y', text: 'Y' }));
			inner.appendChild(h('span', { text: col.name }));
			if (!col.numeric) inner.appendChild(h('span', { class: 'djclr-badge', text: 'not numeric' }));
			inner.appendChild(h('button', {
				type: 'button', class: 'djclr-prune', text: '✕',
				title: 'Prune this column', 'aria-label': 'Prune column ' + col.name,
				onclick: () => { col.pruned = true; markDirty(); renderDataZone(); updateGate(); },
			}));
			trh.appendChild(h('th', null, inner));
		});
		table.appendChild(h('thead', null, trh));

		const tbody = h('tbody', null);
		const nPrev = Math.min(200, t.nRows);
		for (let r = 0; r < nPrev; r++) {
			const tr = h('tr', null);
			t.columns.forEach((col, idx) => {
				if (col.pruned) return;
				let cls = '';
				if (roles && roles.x.i === idx) cls = 'djclr-col-x';
				if (roles && roles.y.i === idx) cls = 'djclr-col-y';
				tr.appendChild(h('td', { class: cls, text: col.cells[r] }));
			});
			tbody.appendChild(tr);
		}
		table.appendChild(tbody);
		dataZone.appendChild(h('div', { class: 'djclr-tablebox' }, table));
		if (t.nRows > nPrev) {
			dataZone.appendChild(h('div', { class: 'djclr-manual-hint', text: 'Showing first ' + nPrev + ' of ' + t.nRows + ' rows. All rows are used in the fit.' }));
		}

		/* pruned tray */
		const pruned = t.columns.map((c, i) => ({ c, i })).filter(e => e.c.pruned);
		if (pruned.length) {
			const tray = h('div', { class: 'djclr-tray' }, h('span', { text: 'Pruned:' }));
			for (const e of pruned) {
				tray.appendChild(h('button', {
					type: 'button', class: 'djclr-tray-chip', text: e.c.name,
					title: 'Restore this column', 'aria-label': 'Restore column ' + e.c.name,
					onclick: () => { e.c.pruned = false; markDirty(); renderDataZone(); updateGate(); },
				}));
			}
			tray.appendChild(h('button', {
				type: 'button', class: 'djclr-ghost', text: 'Restore all',
				onclick: () => { t.columns.forEach(c => { c.pruned = false; }); markDirty(); renderDataZone(); updateGate(); },
			}));
			dataZone.appendChild(tray);
		}

		/* role bar with swap */
		if (roles) {
			dataZone.appendChild(h('div', { class: 'djclr-roles' },
				h('span', { class: 'djclr-role-chip djclr-role-x', text: 'X' }),
				h('span', { class: 'djclr-rolename', text: roles.x.c.name }),
				h('button', {
					type: 'button', text: '⇄ Swap', title: 'Swap which column is X and which is Y',
					onclick: () => { state.upload.swapped = !state.upload.swapped; markDirty(); renderDataZone(); updateGate(); },
				}),
				h('span', { class: 'djclr-role-chip djclr-role-y', text: 'Y' }),
				h('span', { class: 'djclr-rolename', text: roles.y.c.name })));
		} else {
			dataZone.appendChild(h('div', { class: 'djclr-manual-hint', text: 'Prune with ✕ until two columns remain. The first left becomes X, the second Y.' }));
		}
	}

	/* -------------------- manual pane -------------------- */

	function renderManual() {
		const table = h('table', { class: 'djclr-manual-table' });
		table.appendChild(h('thead', null, h('tr', null,
			h('th', null, h('div', { class: 'djclr-th-inner' },
				h('span', { class: 'djclr-role-chip djclr-role-x', text: 'X' }),
				h('span', { text: 'input' }))),
			h('th', null, h('div', { class: 'djclr-th-inner' },
				h('span', { class: 'djclr-role-chip djclr-role-y', text: 'Y' }),
				h('span', { text: 'to predict' }))),
			h('th', null))));
		const tbody = h('tbody', null);
		table.appendChild(tbody);

		const makeInput = (row, key, rowIdx, colIdx) => {
			const inp = h('input', {
				type: 'text', inputmode: 'decimal', value: row[key],
				'aria-label': (key === 'x' ? 'X' : 'Y') + ' value, row ' + (rowIdx + 1),
			});
			inp.addEventListener('input', () => {
				row[key] = inp.value;
				if (rowIdx === state.manual.rows.length - 1 && inp.value.trim() !== '') {
					state.manual.rows.push({ x: '', y: '' });
					tbody.appendChild(makeRow(state.manual.rows[state.manual.rows.length - 1], state.manual.rows.length - 1));
				}
				markDirty();
			});
			inp.addEventListener('paste', (e) => {
				const text = (e.clipboardData || window.clipboardData).getData('text');
				if (!text || (!/[\t\n\r]/.test(text) && !text.includes(','))) return;
				e.preventDefault();
				pasteBlock(text, rowIdx, colIdx);
			});
			return inp;
		};

		const makeRow = (row, rowIdx) => h('tr', null,
			h('td', null, makeInput(row, 'x', rowIdx, 0)),
			h('td', null, makeInput(row, 'y', rowIdx, 1)),
			h('td', null, h('button', {
				type: 'button', class: 'djclr-prune', text: '✕',
				title: 'Delete this row', 'aria-label': 'Delete row ' + (rowIdx + 1),
				onclick: () => {
					state.manual.rows.splice(rowIdx, 1);
					if (!state.manual.rows.length) state.manual.rows.push({ x: '', y: '' });
					markDirty();
					renderDataZone();
				},
			})));

		state.manual.rows.forEach((row, i) => tbody.appendChild(makeRow(row, i)));
		dataZone.appendChild(h('div', { class: 'djclr-tablebox' }, table));
		dataZone.appendChild(h('div', {
			class: 'djclr-manual-hint',
			text: 'Type pairs of numbers, one point per row. Paste from a spreadsheet works too: two columns land as X and Y.',
		}));
	}

	function pasteBlock(text, startRow, startCol) {
		const lines = text.split(/\r\n|\r|\n/).filter(l => l.trim() !== '');
		const grid = lines.map(l => {
			if (l.includes('\t')) return l.split('\t');
			if (l.includes(',')) return l.split(',');
			return l.trim().split(/\s+/);
		});
		for (let r = 0; r < grid.length; r++) {
			const target = startRow + r;
			while (state.manual.rows.length <= target) state.manual.rows.push({ x: '', y: '' });
			const cells = grid[r];
			if (cells.length === 1) {
				state.manual.rows[target][startCol === 0 ? 'x' : 'y'] = cells[0].trim();
			} else {
				state.manual.rows[target].x = String(cells[0]).trim();
				state.manual.rows[target].y = String(cells[1]).trim();
			}
		}
		if (state.manual.rows[state.manual.rows.length - 1].x.trim() !== '' ||
			state.manual.rows[state.manual.rows.length - 1].y.trim() !== '') {
			state.manual.rows.push({ x: '', y: '' });
		}
		markDirty();
		renderDataZone();
		updateGate();
	}

	/* -------------------- simulate -------------------- */

	btnSim.addEventListener('click', () => {
		const g = gate();
		if (!g.ok) return;
		let xs, ys, xName, yName;
		if (state.mode === 'upload') {
			const roles = roleCols();
			xs = roles.x.c.values;
			ys = roles.y.c.values;
			xName = roles.x.c.name;
			yName = roles.y.c.name;
		} else {
			xs = state.manual.rows.map(r => r.x);
			ys = state.manual.rows.map(r => r.y);
			/* trailing blank rows are not data entry mistakes */
			while (xs.length && String(xs[xs.length - 1]).trim() === '' && String(ys[ys.length - 1]).trim() === '') {
				xs.pop(); ys.pop();
			}
			xName = 'X';
			yName = 'Y';
		}
		const res = LR.fit(xs, ys);
		if (!res.ok) {
			const why = res.error === 'CONSTANT_X'
				? 'All X values are identical, and a line needs X to vary. Try Swap, or different columns.'
				: 'Need at least 3 usable points. ' + res.n + ' found after skipping incomplete rows.';
			msg.textContent = why;
			msg.classList.add('djclr-msg-err');
			return;
		}
		state.fit = res;
		state.fitMeta = { xName, yName };
		state.stale = false;
		staleChip.hidden = true;
		plotWrap.classList.remove('djclr-stale');
		results.style.opacity = '';
		renderResults();
		for (const b of Object.values(pillBtns)) b.disabled = false;
		renderPlot();
		updateGate();
	});

	/* -------------------- results -------------------- */

	function stat(label, value, sub) {
		const cell = h('div', { class: 'djclr-stat' },
			h('div', { class: 'djclr-stat-label', text: label }),
			h('div', { class: 'djclr-stat-value', text: value }));
		if (sub) cell.appendChild(h('div', { class: 'djclr-stat-sub', text: sub }));
		return cell;
	}

	function renderResults() {
		const f = state.fit, m = state.fitMeta;
		results.textContent = '';
		results.hidden = false;

		const sign = f.slope < 0 ? ' − ' : ' + ';
		const eq = h('div', { class: 'djclr-eq' },
			h('span', { class: 'djclr-eq-model', text: 'ŷ = ' + fmt(f.intercept) + sign + fmt(Math.abs(f.slope)) + '·x' }));
		results.appendChild(eq);
		results.appendChild(h('div', { class: 'djclr-skipnote', text: 'X = ' + m.xName + ', Y = ' + m.yName }));

		const grid = h('div', { class: 'djclr-statgrid' },
			stat('Slope (b)', fmt(f.slope), '± ' + fmt(f.seSlope, 4) + ' SE'),
			stat('Intercept (a)', fmt(f.intercept), '± ' + fmt(f.seIntercept, 4) + ' SE'),
			stat('Correlation (r)', fmt(f.r, 4)),
			stat('R²', fmt(f.r2, 4)),
			stat('Typical miss (RMSE)', fmt(f.rmse, 4)),
			stat('Points used (n)', String(f.n)));
		results.appendChild(grid);

		if (f.skipped > 0) {
			results.appendChild(h('div', {
				class: 'djclr-skipnote',
				text: f.skipped + ' row' + (f.skipped === 1 ? '' : 's') + ' with missing or non-numeric values ' + (f.skipped === 1 ? 'was' : 'were') + ' skipped.',
			}));
		}
	}

	/* -------------------- charts -------------------- */

	function setLegend(items) {
		legend.textContent = '';
		for (const [type, label] of items) {
			legend.appendChild(h('span', { class: 'djclr-key' },
				h('span', { class: type === 'dot' ? 'djclr-key-dot' : 'djclr-key-line' }),
				h('span', { text: label })));
		}
	}

	let clipSeq = 0;

	function chartBase(xLoIn, xHiIn, yLoIn, yHiIn, xTitle, yTitle) {
		const W = Math.max(svgBox.clientWidth || 0, 280);
		const H = Math.max(svgBox.clientHeight || 0, 240);
		const M = { top: 14, right: 18, bottom: 46, left: 64 };
		const iw = W - M.left - M.right, ih = H - M.top - M.bottom;

		const xt = LR.niceTicks(xLoIn, xHiIn, Math.max(4, Math.min(8, Math.round(iw / 80))));
		const yt = LR.niceTicks(yLoIn, yHiIn, 6);
		const xLo = xt.lo, xHi = xt.hi, yLo = yt.lo, yHi = yt.hi;
		const gx = v => M.left + (v - xLo) / (xHi - xLo) * iw;
		const gy = v => M.top + ih - (v - yLo) / (yHi - yLo) * ih;

		const svg = s('svg', { width: W, height: H, viewBox: '0 0 ' + W + ' ' + H, role: 'img' });
		/* clip box breathes 6px so edge marks are not halved */
		const clipId = 'djclr-clip-' + (++clipSeq);
		svg.appendChild(s('defs', null,
			s('clipPath', { id: clipId },
				s('rect', { x: M.left - 6, y: M.top - 6, width: iw + 12, height: ih + 12 }))));

		for (const tv of yt.ticks) {
			svg.appendChild(s('line', { class: 'djclr-gridline', x1: M.left, x2: M.left + iw, y1: gy(tv), y2: gy(tv) }));
			svg.appendChild(s('text', { class: 'djclr-tick-label', x: M.left - 7, y: gy(tv) + 3.5, 'text-anchor': 'end', text: tickLabel(tv, yt.step) }));
		}
		for (const tv of xt.ticks) {
			svg.appendChild(s('line', { class: 'djclr-axisline', x1: gx(tv), x2: gx(tv), y1: M.top + ih, y2: M.top + ih + 4 }));
			svg.appendChild(s('text', { class: 'djclr-tick-label', x: gx(tv), y: M.top + ih + 16, 'text-anchor': 'middle', text: tickLabel(tv, xt.step) }));
		}
		svg.appendChild(s('line', { class: 'djclr-axisline', x1: M.left, x2: M.left + iw, y1: M.top + ih, y2: M.top + ih }));
		svg.appendChild(s('line', { class: 'djclr-axisline', x1: M.left, x2: M.left, y1: M.top, y2: M.top + ih }));
		svg.appendChild(s('text', { class: 'djclr-axis-title', x: M.left + iw / 2, y: H - 8, 'text-anchor': 'middle', text: xTitle }));
		const yT = s('text', { class: 'djclr-axis-title', 'text-anchor': 'middle', text: yTitle });
		yT.setAttribute('transform', 'translate(14,' + (M.top + ih / 2) + ') rotate(-90)');
		svg.appendChild(yT);

		const plotG = s('g', { 'clip-path': 'url(#' + clipId + ')' });
		svg.appendChild(plotG);
		return { svg, plotG, gx, gy, xLo, xHi, yLo, yHi, M, iw, ih };
	}

	function addPoint(cb, px, py, tipRows) {
		const dot = s('circle', { class: 'djclr-mark djclr-mark-ring', cx: px, cy: py, r: 3.5 });
		const hit = s('circle', { class: 'djclr-hit', cx: px, cy: py, r: 11 });
		hit.addEventListener('pointerenter', () => { dot.classList.add('djclr-hot'); tipShow(dot, tipRows); });
		hit.addEventListener('pointerleave', () => { dot.classList.remove('djclr-hot'); tipHide(); });
		cb.plotG.appendChild(dot);
		cb.plotG.appendChild(hit);
	}

	function renderPlot() {
		for (const [key, b] of Object.entries(pillBtns)) {
			b.setAttribute('aria-pressed', key === state.activePlot);
		}
		svgBox.textContent = '';
		tipHide();
		if (!state.fit) {
			setLegend([]);
			svgBox.appendChild(h('div', { class: 'djclr-plot-empty', text: 'Plots appear here. Enter data on the left, then press Simulate.' }));
			return;
		}
		const f = state.fit, m = state.fitMeta;
		if (state.activePlot === 'scatter') renderScatter(f, m);
		else if (state.activePlot === 'resid') renderResiduals(f, m);
		else if (state.activePlot === 'qq') renderQQ(f);
		else renderHist(f);
	}

	function renderScatter(f, m) {
		setLegend([['dot', 'your data'], ['line', 'fitted line']]);
		const cb = chartBase(Math.min(...f.xs), Math.max(...f.xs),
			Math.min(...f.ys), Math.max(...f.ys), m.xName, m.yName);
		const yAt = x => f.meanY + f.slope * (x - f.meanX);
		cb.plotG.appendChild(s('line', {
			class: 'djclr-modelline',
			x1: cb.gx(cb.xLo), y1: cb.gy(yAt(cb.xLo)),
			x2: cb.gx(cb.xHi), y2: cb.gy(yAt(cb.xHi)),
		}));
		for (let i = 0; i < f.n; i++) {
			addPoint(cb, cb.gx(f.xs[i]), cb.gy(f.ys[i]), [
				[m.xName + ':', fmt(f.xs[i])],
				[m.yName + ':', fmt(f.ys[i])],
				['fitted:', fmt(f.fitted[i], 5)],
				['residual:', fmt(f.residuals[i], 5)],
			]);
		}
		/* direct label on the model line, kept inside the plot area */
		const sign = f.slope < 0 ? ' − ' : ' + ';
		const lx = cb.xLo + (cb.xHi - cb.xLo) * 0.97;
		let ly = yAt(lx);
		/* keep the label well inside the plot, clear of the axes */
		const yPad = (cb.yHi - cb.yLo) * 0.08;
		ly = Math.max(cb.yLo + yPad, Math.min(cb.yHi - yPad, ly));
		const above = f.slope >= 0 ? -9 : 14;
		cb.svg.appendChild(s('text', {
			class: 'djclr-line-label', x: cb.gx(lx), y: cb.gy(ly) + above, 'text-anchor': 'end',
			text: 'ŷ = ' + fmt(f.intercept, 4) + sign + fmt(Math.abs(f.slope), 4) + '·x',
		}));
		svgBox.appendChild(cb.svg);
	}

	function renderResiduals(f, m) {
		setLegend([['dot', 'residual (actual − fitted)'], ['line', 'zero line']]);
		const rLo = Math.min(0, ...f.residuals), rHi = Math.max(0, ...f.residuals);
		const cb = chartBase(Math.min(...f.xs), Math.max(...f.xs), rLo, rHi, m.xName, 'Residual');
		cb.plotG.appendChild(s('line', {
			class: 'djclr-refline',
			x1: cb.gx(cb.xLo), y1: cb.gy(0), x2: cb.gx(cb.xHi), y2: cb.gy(0),
		}));
		for (let i = 0; i < f.n; i++) {
			addPoint(cb, cb.gx(f.xs[i]), cb.gy(f.residuals[i]), [
				[m.xName + ':', fmt(f.xs[i])],
				['residual:', fmt(f.residuals[i], 5)],
			]);
		}
		svgBox.appendChild(cb.svg);
	}

	function renderQQ(f) {
		setLegend([['dot', 'residuals, sorted'], ['line', 'normal reference']]);
		const sorted = f.residuals.slice().sort((a, b) => a - b);
		const zs = LR.ppoints(f.n).map(LR.qnorm);
		const cb = chartBase(zs[0], zs[zs.length - 1], sorted[0], sorted[sorted.length - 1],
			'Theoretical quantiles (z)', 'Residual quantiles');
		const z25 = LR.qnorm(0.25), z75 = LR.qnorm(0.75);
		const q25 = LR.quantileSorted(sorted, 0.25), q75 = LR.quantileSorted(sorted, 0.75);
		if (z75 !== z25 && q75 !== q25) {
			const sl = (q75 - q25) / (z75 - z25);
			const ic = q25 - sl * z25;
			cb.plotG.appendChild(s('line', {
				class: 'djclr-refline',
				x1: cb.gx(cb.xLo), y1: cb.gy(ic + sl * cb.xLo),
				x2: cb.gx(cb.xHi), y2: cb.gy(ic + sl * cb.xHi),
			}));
		}
		for (let i = 0; i < f.n; i++) {
			addPoint(cb, cb.gx(zs[i]), cb.gy(sorted[i]), [
				['z:', fmt(zs[i], 4)],
				['residual:', fmt(sorted[i], 5)],
			]);
		}
		svgBox.appendChild(cb.svg);
	}

	function renderHist(f) {
		setLegend([['dot', 'residual counts'], ['line', 'zero line']]);
		const hg = LR.histogram(f.residuals);
		const maxC = Math.max(...hg.bins.map(b => b.count), 1);
		const first = hg.bins[0], last = hg.bins[hg.bins.length - 1];
		const cb = chartBase(first.x0, last.x1, 0, maxC, 'Residual', 'Count');
		for (const b of hg.bins) {
			const x0 = cb.gx(b.x0), x1 = cb.gx(b.x1);
			const bw = Math.max(1, x1 - x0 - 2);
			const y = cb.gy(b.count);
			const bar = s('rect', {
				class: 'djclr-bar', x: x0 + 1, y,
				width: bw, height: Math.max(0, cb.gy(0) - y), rx: 2,
			});
			bar.addEventListener('pointerenter', () => tipShow(bar, [
				['range:', fmt(b.x0, 4) + ' to ' + fmt(b.x1, 4)],
				['count:', String(b.count)],
			]));
			bar.addEventListener('pointerleave', tipHide);
			cb.plotG.appendChild(bar);
		}
		if (0 >= cb.xLo && 0 <= cb.xHi) {
			cb.plotG.appendChild(s('line', {
				class: 'djclr-refline',
				x1: cb.gx(0), y1: cb.gy(0), x2: cb.gx(0), y2: cb.M.top,
			}));
		}
		svgBox.appendChild(cb.svg);
	}

	if (typeof ResizeObserver !== 'undefined') {
		let raf = 0;
		new ResizeObserver(() => {
			cancelAnimationFrame(raf);
			raf = requestAnimationFrame(() => renderPlot());
		}).observe(svgBox);
	}

	/* -------------------- read me -------------------- */

	function buildReadme() {
		const closeBtn = h('button', { type: 'button', class: 'djclr-ghost', text: 'Close ✕', 'aria-label': 'Close Read Me' });
		const body = h('div', { class: 'djclr-modal-body' });
		body.innerHTML = [
			'<p>This simulator fits a <strong>straight line</strong> through a set of points, the same "line of best fit" you will meet in class as linear regression. You give it pairs of numbers, it finds the line that misses the points by the least, and it shows you both the numbers and the pictures.</p>',
			'<p>Everything runs inside your own browser. Your data is never uploaded, stored, or shared.</p>',
			'<h3>Getting data in</h3>',
			'<ul>',
			'<li><strong>Upload Data</strong>: pick a CSV file (spreadsheets can export one). You will see a preview of every column.</li>',
			'<li><strong>Manual Entry</strong>: type pairs of numbers, one point per row. You can also paste two columns straight from a spreadsheet.</li>',
			'</ul>',
			'<h3>Pruning to two columns</h3>',
			'<p>A line only relates <em>two</em> things, so after an upload you prune, just like cutting columns you do not need in EDA. Click the <code>✕</code> on each column that is not part of your question until two remain. The left survivor becomes <strong>X</strong> (the input) and the right one becomes <strong>Y</strong> (the thing being predicted). Hit <code>⇄ Swap</code> if they are backwards. Pruned columns wait in a tray below the table, so nothing is lost, click one to bring it back and try a different pair.</p>',
			'<h3>The numbers</h3>',
			'<ul>',
			'<li><strong>Slope (b)</strong>: how much Y changes when X goes up by 1.</li>',
			'<li><strong>Intercept (a)</strong>: the Y value the line predicts when X is 0.</li>',
			'<li><strong>Correlation (r)</strong>: how tightly the points hug a straight line, from −1 to +1. Near 0 means no straight-line pattern.</li>',
			"<li><strong>R²</strong>: the share of Y's variation the line explains, from 0 to 1.</li>",
			"<li><strong>Typical miss (RMSE)</strong>: roughly how far off the line is for a typical point, in Y's own units.</li>",
			'<li><strong>SE</strong> (the small ± numbers): how uncertain the slope and intercept are. Smaller means steadier.</li>',
			'</ul>',
			'<h3>The plots</h3>',
			'<ul>',
			'<li><strong>Scatter + Fit</strong>: your points with the fitted line through them. Start here.</li>',
			"<li><strong>Residuals</strong>: each point's miss (actual − fitted) against X. A good fit looks like random scatter around the zero line; a curve or funnel shape means a straight line is not the whole story.</li>",
			'<li><strong>Q-Q</strong>: checks whether the misses follow a bell curve. Points near the reference line mean yes.</li>',
			'<li><strong>Histogram</strong>: the shape of the misses. Roughly bell-shaped and centered on zero is what a healthy fit looks like.</li>',
			'</ul>',
			'<h3>Tips</h3>',
			'<ul>',
			'<li>You need at least 3 points, and X has to vary. Two identical X values are fine; all identical is not a line.</li>',
			'<li>Rows with a missing or non-numeric value are skipped and counted, not silently turned into zeros.</li>',
			'<li>Correlation is not causation. The line describes a pattern, it does not prove X causes Y.</li>',
			'</ul>',
		].join('');

		const panel = h('div', { class: 'djclr-modal-panel' },
			h('div', { class: 'djclr-modal-head' },
				h('h2', { text: 'Read Me: how to use this simulator' }),
				closeBtn),
			body);
		const el = h('div', { class: 'djclr-modal', hidden: true, role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Read Me' }, panel);

		let returnTo = null;
		const close = () => {
			el.hidden = true;
			if (returnTo) returnTo.focus();
		};
		closeBtn.addEventListener('click', close);
		el.addEventListener('click', (e) => { if (e.target === el) close(); });
		document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !el.hidden) close(); });
		return {
			el,
			open(btn) { returnTo = btn; el.hidden = false; closeBtn.focus(); },
		};
	}

	/* -------------------- boot -------------------- */

	setMode('upload');
	renderPlot();
	updateGate();
}

})();
